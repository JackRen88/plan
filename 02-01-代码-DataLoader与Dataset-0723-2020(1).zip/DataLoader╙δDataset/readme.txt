代码使用必读
代码使用必读
代码使用必读

每一节课下载的代码可能包含tools，model文件夹下的.py文件，需要大家手动的将代码按下面的目录存放

每一节课主代码均会对应到 lesson\lesson-[01, 02, 03, ..., 35, 36]，需要大家自行构建文件夹

项目结构如下：

hello pytorch
│ 
├─data
├─lesson
│  ├─lesson-01

     ...此处省略34行

│  ├─lesson-36
├─model
└─tools